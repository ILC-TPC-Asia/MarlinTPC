# Contribution Guidelines

Please have a look at the [contribution guidelines for iLCSoft](https://github.com/iLCSoft/ilcsoftDoc/blob/master/.github/CONTRIBUTING.md)
