void dt2()
{
   TFile *_file0 = TFile::Open("../Data/r20055.root");
   TFile *_file1 = TFile::Open("../Data/r20057.root");
   
   TCanvas *c1 = new TCanvas("c1");
   
   _file0->cd();
   TDirectoryFile *myrootfp0 = static_cast<TDirectoryFile *>(gROOT->FindObject("MyRootFileProcessor"));
   myrootfp0->cd();
   TNtupleD *clrs0 = static_cast<TNtupleD *>(gROOT->FindObject("clrs"));
   clrs0->Draw("dt>>h0(300,7100.,8600)","","goff");
   //clrs0->Draw("dt>>h0(300,7100.,8600)","module==3&&row==16&&(ndf+5)/2<14","goff");
   TH1D *h0 = static_cast<TH1D *>(gROOT->FindObject("h0"));
   h0->Scale(1./h0->Integral());
   h0->Draw("EHIST");
   
   _file1->cd();
   TDirectoryFile *myrootfp1 = static_cast<TDirectoryFile *>(gROOT->FindObject("MyRootFileProcessor"));
   myrootfp1->cd();
   TNtupleD *clrs1 = static_cast<TNtupleD *>(gROOT->FindObject("clrs"));
   clrs1->Draw("dt>>h1(300,7100.,8600)","","goff");
   //clrs1->Draw("dt>>h1(300,7100.,8600)","module==3&&row==16&&(ndf+5)/2<14","goff");
   TH1D *h1 = static_cast<TH1D *>(gROOT->FindObject("h1"));
   h1->Scale(1./h1->Integral());
   h1->Draw("EHIST same");
}
