#define CHECK_DIST
#include <iomanip>
#include "Runinfo.h"
#ifndef __CINT__
#include <sstream>
#include "TROOT.h"
#include "TSystem.h"
#include "TFile.h"
#include "TNtupleD.h"
#include "TH2.h"
#include "TTree.h"

#include "TPaveText.h"
#include "TLatex.h"
#include "TGraphErrors.h"
#include "TCanvas.h"
#include "TF1.h"
#include "TStyle.h"
#endif

void Process(Int_t run, Int_t module, Int_t row, 
             Double_t &x, Double_t &y, Double_t &dx, Double_t &dy);

void Vdrift(Int_t module = 3, Int_t row = 16)
{
//--Set Style
  // Axis
  gStyle->SetLabelFont(22,"X");
  gStyle->SetLabelFont(22,"Y");
  // Title offset
  gStyle->SetTitleOffset(1.0, "X");
  gStyle->SetTitleOffset(1.2, "Y");
  // Pad grid
  gStyle->SetPadGridX(kTRUE);
  gStyle->SetPadGridY(kTRUE);
  // Title
  gStyle->SetTitleFont(22, "X");
  gStyle->SetTitleFont(22, "Y");
  gStyle->SetTitleFont(22, "");
  // -----------
  // Input data
  // -----------
  const Int_t kNp = 15; //10;
  //const Int_t kNp = 11; //15;
  Double_t xdata[kNp], ydata[kNp], dxdata[kNp], dydata[kNp];
  //    dlen [cm]      5     10     15     20     25     30     35     40     45     50
  // 2010 Data
  //Int_t kRun[] = { 17319, 17367, 17324, 17364, 17327, 17359, 17375, 17356, 17340, 17352}; // B=1T
  // 2012 Data
  //Int_t kRun[] = { 18564, 18563, 18562, 18561, 18552, 18551, 18550, 18549, 18548, 18547}; // B=1T
  //Int_t kRun[] = { 18609, 18606, 18605, 18601, 18600, 18598, 18597, 18595, 18594, 18592, 18591}; // B=1T
  // 2016 Data
  //Int_t kRun[] = { 19895, 19894, 19893, 19892, 19891, 19890, 19889, 19888, 19887, 19886, 19885, 19884, 19883, 19882, 19881}; // B=1T phi=-20deg w/gate
  //Int_t kRun[] = { 19987, 19985, 19984, 19983, 19982, 19981, 19980, 19979, 19978, 19977, 19976, 19975, 19974, 19973, 19972}; // B=1T w/gate
  Int_t kRun[] = { 20042, 20041, 20043, 20044, 20045, 20046, 20047, 20048, 20049, 20050, 20051, 20052, 20053, 20054, 20055}; // B=1T w/o gate

  // ---------------
  // Loop over runs
  // ---------------
  Int_t n = 0;
  for (Int_t i=0; i<kNp; i++) {
    Int_t run = kRun[i];
    Double_t x, y, dx, dy;
    Process(run, module, row, x, y, dx, dy);
    
    xdata[i] = x; ydata[i] = y; dxdata[i] = dx; dydata[i] = dy; 
  }

  // ---------------
  // Plot PRF vs z
  // ---------------
  TCanvas *c1 = new TCanvas("c1","",800,500);
  c1->cd();

  TGraphErrors *grp = new TGraphErrors(kNp,xdata,ydata,dxdata,dydata);
  stringstream titlestr;
  titlestr << "Drift Velocity (Module" << module << " Row" << row << ")" << ends;
  grp->SetTitle(titlestr.str().data());
  grp->GetHistogram()->GetXaxis()->SetLimits(0.,600.);
  grp->GetHistogram()->GetXaxis()->SetTitle("Drift Length: z [mm]");
  grp->GetHistogram()->GetYaxis()->SetTitle("time [ns]");
  grp->Draw("ap");
  grp->SetMarkerColor(1);
  grp->SetMarkerStyle(21);
  grp->SetMinimum(0.);
  //Double_t ymax = 8000.;
  Double_t ymax = 8500.;
  grp->SetMaximum(ymax);
  TF1 fun("fun","[0]+[1]*x");
  fun.SetLineStyle(2);
  fun.SetLineColor(2);

  fun.SetParameter(0,0.);
  fun.SetParameter(1,100.);
  //grp->Fit(&fun,"","",10.,600.);
  //grp->Fit(&fun,"","",100.,600.);
  grp->Fit(&fun,"","",0.,600.);
  //grp->Fit(&fun,"","",350.,600.);
  Double_t t0     = fun.GetParameter(0); // [ns]
  Double_t dt0    = fun.GetParError (0); // [ns]
  Double_t vdinv  = fun.GetParameter(1); // [ns/mm]
  Double_t dvdinv = fun.GetParError (1); // [ns/mm]
  Double_t chi2    = fun.GetChisquare();
  Int_t    ndf     = fun.GetNDF();

  TPaveText *pt = new TPaveText(330,1*ymax/10, 530.,1*ymax/10+1.8*ymax/10);

  pt->SetTextFont(132);
  pt->SetTextAlign(12);
  stringstream stext;
  stext << "#chi^{2}/ndf = " << setprecision(3) << chi2 << "/" << ndf << ends;
  pt->AddText(stext.str().data());
  stext.str("");
  stext.clear();
  stext << "t_{0} = " << setw(6) << setprecision(4) << t0
        << " #pm "    << setw(3) << setprecision(2) << dt0
        << " [ns]"    << ends;
  pt->AddText(stext.str().data());
  stext.str("");
  stext.clear();
  stext << "v_{drift} = " << setw(6) << setprecision(4) << 1000./vdinv
        << " #pm "    << setw(3) << setprecision(2) << 1000.*dvdinv/(vdinv*vdinv)
        << " [#mum/ns]" << ends;
  pt->AddText(stext.str().data());
  pt->Draw();

  TLatex *fitfun = new TLatex;
  fitfun->SetTextFont(132);
  fitfun->SetTextAlign(12);
  fitfun->DrawLatex(50.,ymax/2, "t_{d} = t_{0} + z/v_{drift}");

#if 0
  // save plot as pdf file
  Runinfo &rinfo = *Runinfo::GetInstancePtr();
  stringstream ofile;
  ofile << "Vdrift_Module" << module << "_Row" << row << "_B" << rinfo.GetBfield(run) << "T" 
        << "_P" << rinfo.GetMomentum(run) << "GeV.pdf"<< ends;
  c1->Print(ofile.str().data());
#endif
}

void Process(Int_t run, Int_t module, Int_t row, 
             Double_t &x, Double_t &y, Double_t &dx, Double_t &dy)
{
  // ---------------
  // Reset Run Info.
  // ---------------
  Runinfo &rinfo = *Runinfo::GetInstancePtr();
  Double_t dlen  = rinfo.GetDlength(run);

  TDirectory *last = gDirectory;
  stringstream hstr;
  hstr << "c" << "_" << dlen << ends;
#ifdef CHECK_DIST
  TCanvas *cp = new TCanvas(hstr.str().data(),"",400,400);
  cp->cd();
#else
  TCanvas ctemp(hstr.str().data(),"",400,400);
  ctemp.cd();
#endif

  // ---------------
  // Open input file
  // ---------------
  stringstream finstr;
  finstr << "../Data/r" << run << ".root" << ends;
  TFile *hfp = new TFile(finstr.str().data());
  cerr << finstr.str().data() << endl;

  ///// Cuts ////////////////////////
#if 0
  const Int_t    kNdfCut    = 20;
  const Double_t kChi2Cut   = 300.;
  const Double_t kCpaMinCut = -0.2;
  const Double_t kCpaMaxCut =  0.8;
  const Double_t kPhi0MinCut = 4.64;
  const Double_t kPhi0MaxCut = 6.27;
#else
  const Int_t    kNtrks         =  1;
  const Int_t    kNdfCut        = 40;
  const Double_t kChi2Cut       = 40000.;
  const Double_t kCpaMinCut     = -8.0;
  const Double_t kCpaMaxCut     =  2.0;
#if 1 // phi=0
  const Double_t kPhi0MinCut    =  4.64;
  const Double_t kPhi0MaxCut    =  4.72;
#else // phi=-20deg
  const Double_t kPhi0MinCut    =  4.35;
  const Double_t kPhi0MaxCut    =  4.40;
#endif
  //const Double_t kPhi0MinCut    =  -999.;
  //const Double_t kPhi0MaxCut    =  +999.;
#endif
  ///////////////////////////////////
  TNtupleD* hPadRes = static_cast<TNtupleD*>(hfp->Get("MyRootFileProcessor/clrs"));
  stringstream cut;
  cut << "module==" << module      << "&&" 
      << "row=="    << row         << "&&"
      << "ndf>"     << kNdfCut     << "&&"
      << "chi2<"    << kChi2Cut    << "&&"
      << "fi0loc>"  << kPhi0MinCut << "&&"
      << "fi0loc<"  << kPhi0MaxCut << "&&"
      << "cpa>"     << kCpaMinCut  << "&&"
      << "cpa<"     << kCpaMaxCut  << "&&"
      << "ntrks<="  << kNtrks      << ends;
  const Int_t    kNbin =  1000;
  const Double_t kTmin =     0;
  const Double_t kTmax = 10000;
  stringstream cmd;
  cmd << "dt>>htemp(" << kNbin << "," << kTmin << "," << kTmax << ")" << ends;
  hPadRes->Draw(cmd.str().data(),cut.str().data(),"goff");
  TH2D *hq = static_cast<TH2D *>(gROOT->FindObject("htemp"));

  TF1 func("user","[0]*exp(-pow((x-[1])/[2],2)/2.)/sqrt(2*3.141592*[2])",kTmin,kTmax);
  Double_t mu = hq->GetMean();
  Double_t sg = hq->GetRMS();
  func.SetParameter(0,hq->GetEntries());
  func.SetParameter(1,mu);
  func.SetParameter(2,sg);
  //func.SetParameter(3,0.);
  hq->Fit("user","","",mu-4*sg,mu+4*sg);
  mu  = hq->GetFunction("user")->GetParameter(1);
  hq->Fit("user","","",mu-3*sg,mu+3*sg);
  mu  = hq->GetFunction("user")->GetParameter(1);
  hq->Fit("user","","",mu-3*sg,mu+3*sg);

  x  = dlen;
  y  = hq->GetFunction("user")->GetParameter(1);
  dx = 0.1; //FIXME
  dy = hq->GetFunction("user")->GetParError(1);
  const Int_t kcm2mm = 10;
  x  *= kcm2mm;
  dx *= kcm2mm;
  cerr << "x=" << x << " y=" << y << endl;
#ifdef CHECK_DIST
  hq->SetMinimum(0.);
  hq->SetMarkerStyle(4);
  hq->SetMarkerSize(0.7);
  hq->SetMarkerColor(2);
  hq->SetLineColor(2);
  hq->Draw();
  func.Draw("same");
  last->cd();
#endif
}

class dataFile : public TObject
{
  public: 
	  dataFile (Char_t* name, Int_t len) {
	    fname = name;
            flen  = len;
	  }

	  Char_t* getFileName()    { return fname; }
	  Int_t   getDriftLength() { return flen;  }

  private:
	  Char_t* fname; // input file name
	  Int_t    flen; // drift length [cm]
};
