void dt()
{
   TFile *_file0 = TFile::Open("../Data/r20055.root");
   TFile *_file1 = TFile::Open("../Data/r20057.root");
   
   TCanvas *c1 = new TCanvas("c1");
   c1->Divide(2,1);
   
   c1->cd(1);
   _file0->cd();
   TDirectoryFile *myrootfp0 = static_cast<TDirectoryFile *>(gROOT->FindObject("MyRootFileProcessor"));
   myrootfp0->cd();
   TNtupleD *clrs0 = static_cast<TNtupleD *>(gROOT->FindObject("clrs"));
   clrs0->Draw("dt","dt>7000&&dt<9000");
   
   c1->cd(2);
   _file1->cd();
   TDirectoryFile *myrootfp1 = static_cast<TDirectoryFile *>(gROOT->FindObject("MyRootFileProcessor"));
   myrootfp1->cd();
   TNtupleD *clrs1 = static_cast<TNtupleD *>(gROOT->FindObject("clrs"));
   clrs1->Draw("dt","dt>7000&&dt<9000");
}
