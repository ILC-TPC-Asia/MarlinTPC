{
#ifndef __CINT__
  gSystem->Load("libGraf3d");
  gSystem->Load("libPhysics");
  gSystem->Load("libyoka");
  gSystem->Load("libKalTest");
#endif
}
