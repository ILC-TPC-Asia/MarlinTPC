//#define __DEBUG__
#include <iomanip>
#ifndef __CINT__
#include <sstream>
#include "TROOT.h"
#include "TSystem.h"
#include "TFile.h"
#include "TTree.h"
#include "TCanvas.h"

#include "JREvent.h"
#include "JCluster.h"
#endif

const int kMaxWidth  = 200;
const int kMinWidth  =   7;
const int kThreshold =   3;

void ChargeSum(int run = 19987)
{
  stringstream finstr;
  finstr << "root/readout-" << run << "_0.root" << ends;
  cerr << "Infile: " << finstr.str().data() << endl;
  TFile *fp = new TFile(finstr.str().data());
  TFile &f  = *fp;
  TTree *T  = static_cast<TTree *>(f.Get("Event"));
  JREvent *event = 0;
  T->SetBranchAddress("Event", &event);
  Int_t nentries = (Int_t)T->GetEntries();
  cerr << "nentries = " << nentries << endl;

  JCluster::SetSortBy(JCluster::kDet); // set sorting policy

  const int kNlayers = 85;
  TH1F *hSum[kNlayers];
  stringstream ostr;
  for (int l=0; l<kNlayers; l++) {
    ostr << "hSum_" << setw(2) << setfill('0') << l << ends;
    hSum[l] = new TH1F(ostr.str().data(),"",1000,0.,2000.);
    ostr.str("");
    ostr.clear();
  }

  for (Int_t ev=0; ev<nentries; ev++) {
      T->GetEntry(ev);
      if (!(ev%100)) {
        cerr << "ev: " << ev << " evno: " << event->GetEventNumber() << " #cls: " << event->GetEntries() << endl;
      }
      event->Sort(); // sort clusters in ascending order of layers

      int npads     = 0;
      int sum       = 0;
      int layer     = 0;
      int layerlast = 0;
      JCluster *cp;
      TIter next(event);
      while ((cp = static_cast<JCluster *>(next()))) {
#if 1 
        int phmax = cp->GetMaximum();
	int width = cp->GetLength();
        if (phmax < kThreshold || width < kMinWidth || width > kMaxWidth) continue;
#endif
        int module = cp->GetModuleID();
        int llayer = cp->GetLayerID();
        switch (module) {
          case 0:
            layer = llayer;
	    break;
          case 3:
            layer = llayer + 28;
	    break;
          case 5:
            layer = llayer + 56;
	    break;
	  default:
	    continue;
	}
	if (layer != layerlast && npads) {
	  if (layer < kNlayers) {
#ifdef __DEBUG__
            cerr << "layer = " << layerlast << " sum = " << sum << endl;
#endif
            hSum[layer]->Fill(sum);
          }
          sum   = 0;
	  npads = 0;
	}
	//cerr << cp->GetCharge() << endl;
        sum += cp->GetCharge();
	layerlast = layer;
	npads++;
#ifdef __DEBUG__
	//cp->DebugPrint("detail");
#endif
     }
     if (npads && layer < kNlayers) {
#ifdef __DEBUG__
       cerr << "layer = " << layer << " sum = " << sum << endl;
#endif
       hSum[layer]->Fill(sum);
     }
  }
  for (int l=0; l<kNlayers; l++) {
    if (hSum[l]->GetEntries()) {
      stringstream hstr;
      hstr << "c" << "_" << setw(2) << setfill('0') << l << ends;
      TCanvas *cp = new TCanvas(hstr.str().data(),"",400,400);
      cp->cd();
      hSum[l]->Draw();
    }
  } 
}
