//
// $Id: yokaRawMon.C,v 1.8 2012/05/03 09:41:47 fujiik Exp $
//

class GEMDisplay;

//int yokaRawMon(int run = 7049, int part = 0)
//int yokaRawMon(int run = 17180, int part = 0)
//int yokaRawMon(int run = 18594, int part = 0)
int yokaRawMon(int run = 18561, int part = 0)
{
  GEMDisplay *gemdisplay = GEMDisplay::GetInstance();
  gemdisplay->Add("TrackMonitor3D");
  gemdisplay->Add("HitMonitor3D");
  gemdisplay->Add("PadMonitor1");
  gemdisplay->Add("PadMonitor3");
  gemdisplay->Add("PadMonitor6");
  gemdisplay->Add("HitMonitor");
#ifdef __CINT
  gemdisplay->Add("HitMonitor3D");
#if 0
  gemdisplay->Add("PadMonitor1");
  gemdisplay->Add("PadMonitor3");
  gemdisplay->Add("PadMonitor6");
  gemdisplay->Add("HitMonitor");
#endif
#endif
  gemdisplay->SetInputDir("../unpacker/root/");

  gemdisplay->Initialize();
  gemdisplay->GoToEvent(0, run, part);

  return 0;
}
