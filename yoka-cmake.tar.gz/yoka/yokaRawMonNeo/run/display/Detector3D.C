//
// A very primitive pad monitor for ALTRO raw data
//
// by Katsumasa Ikematsu (KEK)
//
// $Id: TrackMonitor3D.C,v 1.5 2011/01/30 18:09:35 fujiik Exp $
//
#ifndef __CINT__
#include "TROOT.h"
#include "TSystem.h"
#include "TStyle.h"
#include "TFile.h"
#include "TH1.h"
#include "TCanvas.h"
#include "TView.h"
#include "TTUBE.h"
#include "TTUBS.h"
#include "TMath.h"
#include "TVector3.h"

#include <sstream>
#endif
#include "TNode.h"

//#define __MOVIE__
#define SEP_2010

///////////////////////////////////////
//-----------------------------------//
//  Pulse shape (height/width) cuts  //
//-----------------------------------//
///////////////////////////////////////
#if 1
//const int kMaxWidth  = 200;
const int kMaxWidth  = 60;
const int kMinWidth  =  7;
//const int kThreshold =  3; // 8;
const int kThreshold =  4;
//const int kThreshold =  5;
#else
const int kMaxWidth  = 15;
const int kMinWidth  =  5;
const int kThreshold =  90;
#endif
const double kCosThetaCut = 0.98;
const int    kMaxMissing  =  15;
//const int    kMinNhits    =  10;
const int    kMinNhits    =  22;
const int    kZdiffCut    = 5.0;
///////////////////////////////////////

TNode *gWorldNodePtr = 0;
TNode *gDetNodePtr   = 0;
TNode *gMnNodePtr[7] = {0, 0, 0, 0, 0, 0, 0};

void Detector3D(const Char_t *oed = "") {
  //gROOT->LoadMacro("SetGlobalStyle.C");
  //gROOT->ProcessLine("SetGlobalStyle()");
  //--
  // Create a 3D viewer
  //--
  TView   *vwp = TView::CreateView(1,0,0);
  const Double_t kRangeXY = 230.;
  vwp->SetRange(-kRangeXY, -kRangeXY*1024./768.,-5.,+kRangeXY, +kRangeXY*1024./768., +595.);
  Int_t ierr;
#if 0
  vwp->SetView(190.,80.,80.,ierr); // 3D view
#else
  vwp->SetView(0.,0.,0.,ierr); // Top view
  // vwp->SetView(0.,90.,0.,ierr); // Side view
#endif
  //--
  // Create a crude LP1 model
  //--
  if (!gWorldNodePtr) {
    const Double_t kRout  = 370.;
    const Double_t kHalfL = 300.;
    new TTUBE("World","World","void",300.,300.,300.);
    new TTUBE("Det","Det","void", kRout, kRout, kHalfL);
    gWorldNodePtr = new TNode("WNode","WNode","World",0.,0.,0.);
    gWorldNodePtr->cd();
    gDetNodePtr   = new TNode("DNode","DNode","Det",0.,0., kHalfL);
    gWorldNodePtr->SetVisibility(0);

#if 0
    const Double_t kDphi[2]  = { 0.000821484, 0.000753027}; // delta phi per pad
    const Int_t    kNpad[2]  = {        176,         192}; // # pads per row
#endif
    const Int_t    kNrow     = 28;
    const Double_t kDr       = 5.36;
    const Double_t kRmin     = 1440.01;
    const Double_t kGap      = 0.10;
    const Double_t kRad2Deg  = 180./TMath::Pi();
    const Double_t kPhiWidth = 0.14464384*kRad2Deg;
    const Double_t kRmax     = kRmin + kNrow*kDr - kGap;
    const Double_t kZ        = 0.;
    const Double_t kPhi0[7]  = {0.12485582, -0.021577304,
                                0.2208493 , 0.07441581, -0.07184279,
                                0.15976241, 0.013329281 };
    const Double_t kR0  [7]  = {1676.115 , 1676.115,
                                1503.615, 1503.615, 1503.615,
                                1332.000 , 1332.000 };
    const Char_t  *kName[7]  = {"M0", "M1", "M2", "M3", "M4", "M5", "M6"};

    for (Int_t module=0; module<7; module++) {
      new TTUBS(kName[module], kName[module],
               "void", kRmin, kRmax, kZ, 
               90. - kPhi0[module]*kRad2Deg,
               90. - kPhi0[module]*kRad2Deg + kPhiWidth);
      string rotname("rot");
      rotname += kName[module];
      new TRotMatrix(rotname.data(), rotname.data(),
                     90., 0.,
                     90.,90.,
                      0., 0.);
      TVector3 xv(0.,-kR0[module],0.);
      string nodename("N");
      nodename += kName[module];
      gMnNodePtr[module] =  new TNode(nodename.data(), nodename.data(), kName[module],
                                      xv.X(),xv.Y(),xv.Z(),
                                      rotname.data());
#ifdef SEP_2010
      if (module != 0 && module != 3 && module != 5) { // active modules are 0, 3, and 5 now.
#else
      if (module != 1 && module != 3 && module != 6) { // active modules are 1, 3, and 6 now.
#endif
        gMnNodePtr[module]->SetLineStyle(2); // dummy module with dashed lines
      }
    }
  }
  gROOT->ProcessLine(oed);
  gWorldNodePtr->Draw("pad same");
}
