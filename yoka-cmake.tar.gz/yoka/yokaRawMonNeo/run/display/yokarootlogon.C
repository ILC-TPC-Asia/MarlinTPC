{
#ifndef __CINT__
  gSystem->Load("libPhysics.so");
  gSystem->Load("libGraf3d.so");
  gSystem->Load("libTree.so");
  gSystem->Load("libKalTest");
  gSystem->Load("libyoka");
#endif
}
