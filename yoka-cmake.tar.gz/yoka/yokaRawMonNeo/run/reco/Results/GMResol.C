#define CHECK_DIST
#include <iomanip>
#include "Runinfo.h"

void Process(Int_t run, Int_t layer, Double_t &x, Double_t &y, Double_t &dx, Double_t &dy, const Char_t *inout);

void GMResol(Int_t module = 3, Int_t row = 16)
{
//--Set Style
  // Axis
  gStyle->SetLabelFont(22,"X");
  gStyle->SetLabelFont(22,"Y");
  // Title offset
  gStyle->SetTitleOffset(1.0, "X");
  gStyle->SetTitleOffset(1.2, "Y");
  // Pad grid
  gStyle->SetPadGridX(kTRUE);
  gStyle->SetPadGridY(kTRUE);
  // Title
  gStyle->SetTitleFont(22, "X");
  gStyle->SetTitleFont(22, "Y");
  gStyle->SetTitleFont(22, "");

  const Int_t kNp = 15; //11;
  Double_t xdata[kNp], ydata[kNp], dxdata[kNp], dydata[kNp];
  //    dlen [cm]      5     10     15     20     25     30     35     40     45     50
  //Int_t kRun[] = { 17319, 17367, 17324, 17364, 17327, 17359, 17375, 17356, 17340, 17352}; // B=1T
  //Int_t kRun[] = { 17319, 17367, 17324, 17364, 17327, 17359, 17331, 17356, 17340, 17352}; // B=1T
  //Int_t kRun[] = { 18564, 18563, 18562, 18561, 18552, 18551, 18550, 18549, 18548, 18547}; // B=1T
  //Int_t kRun[] = { 18609, 18606, 18605, 18601, 18600, 18598, 18597, 18595, 18594, 18592, 18591}; // B=1T
  //Int_t kRun[] = { 19895, 19894, 19893, 19892, 19891, 19890, 19889, 19888, 19887, 19886, 19885, 19884, 19883, 19882, 19881}; // B=1T phi=-20deg
  Int_t kRun[] = { 19987, 19985, 19984, 19983, 19982, 19981, 19980, 19979, 19978, 19977, 19976, 19975, 19974, 19973, 19972}; // B=1T
  //Int_t kRun[] = { 20042, 20041, 20043, 20044, 20045, 20046, 20047, 20048, 20049, 20050, 20051, 20052, 20053, 20054, 20055}; // B=1T

  Int_t layer = (module < 2 ? 0 : module < 5 ? 28 : 56) + row;

  // ---------------
  // Loop over runs
  // ---------------
  Int_t n = 0;
  for (Int_t i=0; i<kNp; i++) {
    Int_t run = kRun[i];
    Double_t xin, yin, dxin, dyin;
    Process(run, layer, xin, yin, dxin, dyin, "in");

    Double_t xot, yot, dxot, dyot;
    Process(run, layer, xot, yot, dxot, dyot, "ot");

    Double_t y  = TMath::Sqrt(yin*yot);
    Double_t dy = (dyin+dyot)/2;

    xdata[n] = xin; ydata[n] = y; dxdata[n] = dxin; dydata[n] = dy; n++;
    cerr << " sigma = " << y << "+/-" << dy << endl;
  }
  // ------------------------
  // Fill z v.s. sigma_x plot
  // ------------------------
  TCanvas *c1 = new TCanvas("c1","",800,500);
  c1->cd();

  TGraphErrors *grp = new TGraphErrors(n,xdata,ydata,dxdata,dydata);
  stringstream titlestr;
  titlestr << "Yoka GM Resolutin (Module" << module << " Row" << row << ")" << ends;
  grp->SetTitle(titlestr.str().data());
  grp->GetHistogram()->GetXaxis()->SetLimits(0.,550.);
  grp->GetHistogram()->GetXaxis()->SetTitle("Drift Length: z [mm]");
  grp->GetHistogram()->GetYaxis()->SetTitle("#sigma_{x} [mm]");
  grp->Draw("ap");
  grp->SetMarkerColor(1);
  grp->SetMarkerStyle(21);
  double ymin = 0.0;
  //double ymax = 0.8;
  double ymax = 0.3;
  grp->SetMinimum(ymin);
  grp->SetMaximum(ymax);
  TF1 fun("fun","sqrt([0]**2+[1]**2*x)");
  fun.SetLineStyle(2);
  fun.SetLineColor(2);
  //grp->Fit(&fun,"","",100.,600.);
  //grp->Fit(&fun,"","",150.,600.);
  grp->Fit(&fun,"","",200.,600.);
  Double_t sigma0        = fun.GetParameter(0) * 1.e3;             // [#mum]
  Double_t dsigma0       = fun.GetParError (0) * 1.e3;             // [#mum]
  Double_t cdbyrootneff  = fun.GetParameter(1) * sqrt(10.) * 1e3;  // [#mum/#sqrt{cm}]
  Double_t dcdbyrootneff = fun.GetParError (1) * sqrt(10.) * 1e3;  // [#mum/#sqrt{cm}]
  Double_t chi2          = fun.GetChisquare();
  Int_t    ndf           = fun.GetNDF();

  TPaveText *pt = new TPaveText(330,3.9*ymax/5, 530.,4.9*ymax/5);

  pt->SetFillColor(0);
  pt->SetTextFont(132);
  pt->SetTextAlign(12);
  stringstream stext;
  stext << "#chi^{2}/ndf = " << setprecision(3) << chi2 << "/" << ndf << ends;
  pt->AddText(stext.str().data());
  stext.str("");
  stext.clear();
  pt->Draw();
  stext << "#sigma_{0} = " << setw(6) << setprecision(3) << sigma0
        << " #pm " << setw(4) << setprecision(2) << dsigma0
        << " [#mum]" << ends;
  pt->AddText(stext.str().data());
  stext.str("");
  stext.clear();
  stext << "C_{D}/#sqrt{N_{eff}} = " << setw(6) << setprecision(3) << cdbyrootneff 
        << " #pm " <<  setw(4) << setprecision(2) << dcdbyrootneff 
        << " [#mum/#sqrt{cm}]" << ends;
  pt->AddText(stext.str().data());
  pt->Draw();

  TLatex *fitfun = new TLatex;
  fitfun->SetTextFont(132);
  fitfun->SetTextAlign(12);
  fitfun->DrawLatex(100,4*ymax/5, "#sigma_{x} = #sqrt{#sigma_{0}^{2}+(C_{D}^{2}/N_{eff}) z}");

#if 0
  // save plot as pdf  file
  Runinfo &rinfo = *Runinfo::GetInstancePtr();
  stringstream ofile;
  ofile << "GMResol_Row" << layer << "_B" << rinfo.GetBfield(run) << "T"
        << "_P" << rinfo.GetMomentum(run) << "GeV.pdf"<< ends; 
  c1->Print(ofile.str().data());
#endif
}

void Process(Int_t run, Int_t layer, Double_t &x, Double_t &y, Double_t &dx, Double_t &dy, const Char_t *inout)
{
  // ---------------
  // Reset Run Info.
  // ---------------
  Runinfo &rinfo = *Runinfo::GetInstancePtr();

#ifdef CHECK_DIST
  stringstream hstr;
  hstr << "c" << "_" << rinfo.GetDlength(run) << "_" << inout << ends;
  TCanvas *cp = new TCanvas(hstr.str().data(),hstr.str().data(),400,400);
  cp->cd();
#endif

#if 1
  cerr << " run = " << run << " dl = " << rinfo.GetDlength(run) << endl;
#endif
  // ---------------
  // Open input file
  // ---------------
  stringstream finstr;
  finstr << "../Data/run" << run << ".root" << ends;
  cerr << "opening " << finstr.str().data() << endl;
  TFile *hfp = new TFile(finstr.str().data());

  // -----------------
  // Get residual data
  // -----------------
  TNtupleD *hResXin = static_cast<TNtupleD *>(gROOT->FindObject("hResXin"));
  stringstream item;
  item << "dx" << inout << setw(2) << setfill('0') << layer << ends;
  stringstream cut;

  ///// Cuts ////////////////////////
#if 0
#if 0
  const Double_t kResXmin   = -0.1;
  const Double_t kResXmax   = +0.1;
  const Int_t    kNdfCut    =  28;
  const Double_t kChi2Cut   = 9000.;
  const Double_t kCpaMinCut = -0.8;
  const Double_t kCpaMaxCut =  0.4;
  const Double_t kPhi0MinCut = 6.22;
  const Double_t kPhi0MaxCut = 6.28;
  const Double_t kTanlMinCut = -0.02;
  const Double_t kTanlMaxCut = +0.02;
#else
  const Double_t kResXmin   = -0.10;
  const Double_t kResXmax   = +0.10;
  //const Double_t kResXmin   = -0.15;
  //const Double_t kResXmax   = +0.15;
#if 0
  //const Int_t    kNdfCut    =   155;
  const Int_t    kNdfCut    =  130;
  //const Int_t    kNdfCut    =  140;
  //const Int_t    kNdfCut    =  100;
  //const Double_t kChi2Cut   = 80000.;
  //const Double_t kChi2Cut   = 40000.;
  //const Double_t kChi2Cut   = 10000.;
  const Double_t kChi2Cut   = 40000.;
  const Double_t kCpaMinCut =  0.3;
  const Double_t kCpaMaxCut =  0.5;
#else
  //const Int_t    kNdfCut    =  32;
  //const Int_t    kNdfCut    =  28;
  //const Int_t    kNdfCut    =  24;
  //const Int_t    kNdfCut    =  140;
  const Int_t    kNdfCut    =  155;
  const Double_t kChi2Cut   = 300.;
  //const Double_t kCpaMinCut = -0.2;
  //const Double_t kCpaMaxCut =  0.8;
  const Double_t kCpaMinCut = -4.;
  const Double_t kCpaMaxCut =  4.;
#endif
  //const Double_t kPhi0MinCut = 6.245;
  //const Double_t kPhi0MaxCut = 6.275;
  //const Double_t kPhi0MinCut = 6.24;
  //const Double_t kPhi0MaxCut = 6.27;
  //const Double_t kPhi0MinCut = 6.22;
  //const Double_t kPhi0MaxCut = 6.28;
  //const Double_t kPhi0MinCut = 6.00;
  //const Double_t kPhi0MaxCut = 6.50;
  const Double_t kPhi0MinCut = 6.218;
  const Double_t kPhi0MaxCut = 6.314;
  const Double_t kTanlMinCut = -0.02;
  const Double_t kTanlMaxCut = +0.02;
  const Double_t kPkPhMinCut =  10.;
  const Double_t kPkPhMaxCut =  900.;
#endif
#else
#if 1
  const Double_t kResXmin   = -0.08;
  const Double_t kResXmax   = +0.08;
#else
  const Double_t kResXmin   = -0.2;
  const Double_t kResXmax   = +0.2;
#endif
#if 0
  const Int_t    kNdfCut    = 100; //117;
  const Double_t kChi2Cut   = 5000.;
  //const Double_t kCpaMinCut = -0.2;
  //const Double_t kCpaMaxCut =  1.2;
  //const Double_t kCpaMinCut =  -1.5; //-0.2;
  //const Double_t kCpaMaxCut =   2.5; // 0.8;
  const Double_t kCpaMinCut =  -0.2;
  const Double_t kCpaMaxCut =   0.8;
  const Double_t kPhi0MinCut =  6.20; // 6.24; //+6.218;
  const Double_t kPhi0MaxCut =  6.31; // 6.27; // 6.314;
  const Double_t kTanlMinCut = -0.02;
  const Double_t kTanlMaxCut = +0.02;
  const Double_t kPkPhMinCut =  10.;
  const Double_t kPkPhMaxCut =  900.;
#else
  //const Int_t    kNdfCut    = 40; //80; //117;
  const Int_t    kNdfCut    = 44; //80; //117;
  const Double_t kChi2Cut   = 40000.;
  //const Double_t kCpaMinCut = -0.2;
  //const Double_t kCpaMaxCut =  1.2;
  //const Double_t kCpaMinCut =  -1.5; //-0.2;
  //const Double_t kCpaMaxCut =   2.5; // 0.8;
  const Double_t kCpaMinCut =   -8;
  const Double_t kCpaMaxCut =    2;
  //const Double_t kCpaMinCut =   -0.8;
  //const Double_t kCpaMaxCut =    0.4;

  const Double_t kPhi0MinCut = -99999; // 6.24; //+6.218;
  const Double_t kPhi0MaxCut = +99999; // 6.27; // 6.314;
  //const Double_t kPhi0MinCut = -0.075; // 6.24; //+6.218;
  //const Double_t kPhi0MaxCut = +0.075; // 6.27; // 6.314;

  const Double_t kTanlMinCut = -99999.; // -0.01; // -99999;
  const Double_t kTanlMaxCut = +99999.; // +0.01; // +99999;
  const Double_t kPkPhMinCut =  10.; // 10.;
  const Double_t kPkPhMaxCut =  900.;
  //const Double_t kPhi0TrkMinCut = -0.01;
  //const Double_t kPhi0TrkMaxCut = +0.015;
  const Double_t kPhi0TrkMinCut = -99999.;
  const Double_t kPhi0TrkMaxCut = +99999.;
#endif
#endif
  ///////////////////////////////////
  cut << item.str().data() << ">" << kResXmin << "&&"
      << item.str().data() << "<" << kResXmax << "&&"
      << "ndf>"  << kNdfCut    << "&&"
      << "chi2<" << kChi2Cut   << "&&"
      << "((fi0>"<< kPhi0TrkMinCut << "&&"
      << "fi0<"  << kPhi0TrkMaxCut << ")||"
#if 0
      << "(fi0+2*TMath::Pi()"  << kPhi0TrkMinCut << "&&"
      << "fi0+2*TMath::Pi()<"  << kPhi0TrkMaxCut << "))&&"
#else
      << "(fi0-2*TMath::Pi()>"  << kPhi0TrkMinCut << "&&"
      << "fi0-2*TMath::Pi()<"  << kPhi0TrkMaxCut << "))&&"
#endif
      << "((fi0" << setw(2) << setfill('0') << layer << ">"<< kPhi0MinCut << "&&"
      << "fi0"   << setw(2) << setfill('0') << layer << "<"  << kPhi0MaxCut << ")||"
#if 0
      << "(fi0"  << setw(2) << setfill('0') << layer << "+2*TMath::Pi()>"  << kPhi0MinCut << "&&"
      << "fi0"   << setw(2) << setfill('0') << layer << "+2*TMath::Pi()<"  << kPhi0MaxCut << "))&&"
#else
      << "(fi0"  << setw(2) << setfill('0') << layer << "-2*TMath::Pi()>"  << kPhi0MinCut << "&&"
      << "fi0"   << setw(2) << setfill('0') << layer << "-2*TMath::Pi()<"  << kPhi0MaxCut << "))&&"
#endif
      << "tnl>"  << kTanlMinCut << "&&"
      << "tnl<"  << kTanlMaxCut << "&&"
      << "pk" << setw(2) << setfill('0') << layer << ">" << kPkPhMinCut << "&&"
      << "pk" << setw(2) << setfill('0') << layer << "<" << kPkPhMaxCut;
  if (rinfo.GetBfield(run)) {
    cut << "&&"
      //  << "xbar"  << layer << ">2442&&"
      //  << "xbar"  << layer << "<2450&&"
      //  << "xbar"  << layer << ">2440&&"
      //  << "xbar"  << layer << "<2470&&"
        << "cpa>"  << kCpaMinCut << "&&"
        << "cpa<"  << kCpaMaxCut;
  }
  cut << ends;
  stringstream target;
  //target << item.str().data() << ">>htemp(100," << kResXmin << ", " << kResXmax << ")" << ends;
  target << item.str().data() << ">>htemp(50," << kResXmin << ", " << kResXmax << ")" << ends;
  hResXin->Draw(target.str().data(), cut.str().data());
  TH1 *htemp = static_cast<TH1 *>(gROOT->FindObject("htemp"));

  // -----------------
  // Fit residuals
  // -----------------
  htemp->Rebin(1);
  htemp->Fit("gaus","RI","",-0.3,0.3);
  Double_t mu  = htemp->GetFunction("gaus")->GetParameter(1);
  Double_t sg  = htemp->GetFunction("gaus")->GetParameter(2);
  htemp->Fit("gaus","RI","",mu-2.5*sg,mu+2.5*sg);

  x  = rinfo.GetDlength(run);
  y  = htemp->GetFunction("gaus")->GetParameter(2); // sigma
  dx = 0;
  dy = htemp->GetFunction("gaus")->GetParError(2);  // its error
  x  *= 10.; // [cm] to [mm]
  y  *= 10.; // [cm] to [mm]
  dx *= 10.; // [cm] to [mm]
  dy *= 10.; // [cm] to [mm]
#ifdef CHECK_DIST
  htemp->SetMinimum(-0.1);
  htemp->SetMarkerStyle(4);
  htemp->SetMarkerSize(0.7);
  htemp->SetMarkerColor(2);
  htemp->SetLineColor(2);
  htemp->Draw("pe");
#endif
}
