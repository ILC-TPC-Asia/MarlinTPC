#include <iomanip>
#include "Runinfo.h"

void Process(Int_t run, Int_t layer, Double_t &x, Double_t &y, Double_t &dx, Double_t &dy, const Char_t *inout);

void Fit(Int_t module = 3, Int_t row = 16, const Char_t *inout = "in")
{
  const Int_t kNp = 15; //11;
  Double_t xdata[kNp], ydata[kNp], dxdata[kNp], dydata[kNp];
  //    dlen [cm]      5     10     15     20     25     30     35     40     45     50
  //Int_t kRun[] = { 17319, 17367, 17324, 17364, 17327, 17359, 17375, 17356, 17340, 17352}; // B=1T
  //Int_t kRun[] = { 17319, 17367, 17324, 17364, 17327, 17359, 17331, 17356, 17340, 17352}; // B=1T
  //Int_t kRun[] = { 18564, 18563, 18562, 18561, 18552, 18551, 18550, 18549, 18548, 18547}; // B=1T
  //Int_t kRun[] = { 18609, 18606, 18605, 18601, 18600, 18598, 18597, 18595, 18594, 18592, 18591}; // B=1T
  //Int_t kRun[] = { 19895, 19894, 19893, 19892, 19891, 19890, 19889, 19888, 19887, 19886, 19885, 19884, 19883, 19882, 19881}; // B=1T phi=-20deg
  Int_t kRun[] = { 19987, 19985, 19984, 19983, 19982, 19981, 19980, 19979, 19978, 19977, 19976, 19975, 19974, 19973, 19972}; // B=1T
  //Int_t kRun[] = { 20042, 20041, 20043, 20044, 20045, 20046, 20047, 20048, 20049, 20050, 20051, 20052, 20053, 20054, 20055}; // B=1T

  Int_t layer = (module < 2 ? 0 : module < 5 ? 28 : 56) + row;

  Double_t x, y, dx, dy;
  Int_t n = 0;
  for (Int_t i=0; i<kNp; i++) {
    cerr << kRun[i] << endl;
    Process(kRun[i], layer, x, y, dx, dy, inout);
    xdata[n] = x; ydata[n] = y; dxdata[n] = dx; dydata[n] = dy; n++; 
  }

  TGraphErrors *grp = new TGraphErrors(n,xdata,ydata,dxdata,dydata);
  grp->Draw("ap");
  grp->SetMarkerColor(1);
  grp->SetMarkerStyle(21);
  grp->SetMinimum(0.);
  grp->SetMaximum(0.25);
  TF1 fun("fun","[0]**2+[1]**2*x");
  fun.SetLineStyle(2);
  fun.SetLineColor(2);
  grp->Fit(&fun);
  grp->Fit(&fun);
}

void Process(Int_t run, Int_t layer, Double_t &x, Double_t &y, Double_t &dx, Double_t &dy, const Char_t *inout)
{
  // ---------------
  // Reset Run Info.
  // ---------------
  Runinfo &rinfo = *Runinfo::GetInstancePtr();

  stringstream finstr;
  finstr << "../Data/run" << run << ".root" << ends;
  cerr << "opening " << finstr.str() << endl;
  TFile *hfp = new TFile(finstr.str().data());
  TNtupleD *hResXin = static_cast<TNtupleD *>(gROOT->FindObject("hResXin"));

  stringstream item;
  item << "dx" << inout << setw(2) << setfill('0') << layer << ends;

  stringstream cut;
  //cut << "abs(" << item.str().data() << ")<0.4&&ndf>150" << ends;
  cut << "abs(" << item.str().data() << ")<0.4&&ndf>40" << ends;

  hResXin->Draw(item.str().data(), cut.str().data());
  TH1 *htemp = static_cast<TH1 *>(gROOT->FindObject("htemp"));
  htemp->Fit("gaus");

  x  = rinfo.GetDlength(run);
  y  = htemp->GetFunction("gaus")->GetParameter(2);
  dx = 0;
  dy = htemp->GetFunction("gaus")->GetParError(2);
  x  *= 10.;
  y  *= 10.;
  dx *= 10.;
  dy *= 10.;
}
