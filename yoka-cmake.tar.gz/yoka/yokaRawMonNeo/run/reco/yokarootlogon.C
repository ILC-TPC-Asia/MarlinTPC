{
#ifndef __CINT__
  gSystem->Load("libPhysics");
  gSystem->Load("libGraf3d");
  gSystem->Load("libTree");
  gSystem->Load("libKaltest");
  gSystem->Load("libyoka");
#endif
}
