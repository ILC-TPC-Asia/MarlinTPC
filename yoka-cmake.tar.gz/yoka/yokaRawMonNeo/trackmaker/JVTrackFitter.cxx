#include "JVTrackFitter.h"

ClassImp(JVTrackFitter)

JVTrackFitter::JVTrackFitter(TVKalDetector *kaldp)
             : fKalDetPtr(kaldp)
{
}

JVTrackFitter::~JVTrackFitter()
{
}
