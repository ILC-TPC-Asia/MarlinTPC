#include "JVTrackFinder.h"

ClassImp(JVTrackFinder)

JVTrackFinder::JVTrackFinder(JTrackMaker *tmp)
             : fTrackMakerPtr(tmp)
{
}

JVTrackFinder::~JVTrackFinder()
{
}
