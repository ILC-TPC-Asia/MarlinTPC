#ifdef __CINT__

#pragma link off all globals;
#pragma link off all classes;
#pragma link off all functions;

#pragma link C++ class JTrack+;
#pragma link C++ class JTrackMaker+;
#pragma link C++ class JHelix+;
#pragma link C++ class JVTrackFinder+;
#pragma link C++ class JSimpleTrackFinder+;
#pragma link C++ class JTripletTrackFinder+;
#pragma link C++ class JVTrackFitter+;
#pragma link C++ class JSimpleTrackFitter+;

#endif
