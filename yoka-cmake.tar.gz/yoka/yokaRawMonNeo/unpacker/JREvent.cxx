#include "JREvent.h"

ClassImp(JREvent)

JREvent::JREvent()
      : fEventNo(0)
{
  SetOwner();
}
