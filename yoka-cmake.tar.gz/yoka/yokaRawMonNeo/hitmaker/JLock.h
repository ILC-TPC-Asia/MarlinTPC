static const Int_t kLock   = 18;
static const Int_t kMyOwn  = 19;
static const Int_t kUsed   = 20;
