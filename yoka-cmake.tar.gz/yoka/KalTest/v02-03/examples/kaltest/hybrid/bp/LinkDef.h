#ifdef __CINT__

#pragma link off all globals;
#pragma link off all classes;
#pragma link off all functions;

#pragma link C++ class EXBPKalDetector+;
#pragma link C++ class EXBPHit+;
#pragma link C++ class EXBPMeasLayer+;
#pragma link C++ class EXBPConeHit+;
#pragma link C++ class EXBPConeMeasLayer+;

#endif
