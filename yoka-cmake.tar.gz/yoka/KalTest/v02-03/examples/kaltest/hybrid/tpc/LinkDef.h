#ifdef __CINT__

#pragma link off all globals;
#pragma link off all classes;
#pragma link off all functions;

#pragma link C++ class EXTPCKalDetector+;
#pragma link C++ class EXTPCHit+;
#pragma link C++ class EXTPCMeasLayer+;

#endif
