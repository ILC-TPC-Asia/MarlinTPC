#ifdef __CINT__

#pragma link off all globals;
#pragma link off all classes;
#pragma link off all functions;

#pragma link C++ class EXITKalDetector+;
#pragma link C++ class EXITHit+;
#pragma link C++ class EXITFBHit+;
#pragma link C++ class EXITMeasLayer+;
#pragma link C++ class EXITFBMeasLayer+;

#endif
