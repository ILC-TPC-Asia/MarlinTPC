#ifdef __CINT__

#pragma link off all globals;
#pragma link off all classes;
#pragma link off all functions;

#pragma link C++ class EXVTXKalDetector+;
#pragma link C++ class EXVTXHit+;
#pragma link C++ class EXVTXMeasLayer+;

#endif
