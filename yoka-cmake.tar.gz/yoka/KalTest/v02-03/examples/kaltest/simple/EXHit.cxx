#include "EXHit.h"

ClassImp(EXHit)
