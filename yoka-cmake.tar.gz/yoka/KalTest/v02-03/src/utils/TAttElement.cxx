//*************************************************************************
//* ===================
//*  TAttElement Class
//* ===================
//*
//* (Description)
//*    TAttElement class adds constituent attribute to an object.
//* (Requires)
//* 	none
//* (Provides)
//* 	class TAttElement
//* (Update Recored)
//*    2003/10/10  K.Fujii	Original very primitive version.
//*
//*************************************************************************
//
#include "TAttElement.h"
//_____________________________________________________________________
//  --------------------------------
//  Base Class for Element Objects
//  --------------------------------
//

ClassImp(TAttElement)
