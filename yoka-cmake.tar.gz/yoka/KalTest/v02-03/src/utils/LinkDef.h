#ifdef __CINT__

#pragma link off all globals;
#pragma link off all classes;
#pragma link off all functions;

#pragma link C++ class TAttDrawable+;
#pragma link C++ class TAttElement+;
#pragma link C++ class TAttLockable+;

#endif
