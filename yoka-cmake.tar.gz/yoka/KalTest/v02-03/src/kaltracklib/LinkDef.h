#ifdef __CINT__

#pragma link off all globals;
#pragma link off all classes;
#pragma link off all functions;

#pragma link C++ class TVTrackHit+;
#pragma link C++ class TVMeasLayer+;
#pragma link C++ class TKalTrackSite+;
#pragma link C++ class TKalTrackState+;
#pragma link C++ class TKalTrack+;
#pragma link C++ class TKalDetCradle+;
#pragma link C++ class TVKalDetector+;
#pragma link C++ class TKalFilterCond+;
#pragma link C++ class TTrackFrame+;

#endif
