#ifndef KALDIM_H
#define KALDIM_H
#define kMdim 2
#ifdef __NOT0__
#define kSdim 5
#else
#define kSdim 6
#endif
#endif
